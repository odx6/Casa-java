package futuroingeniero;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.util.glu.GLU.*;
import org.lwjgl.util.glu.Sphere;
import org.newdawn.slick.opengl.Texture;
import org.newdawn.slick.opengl.TextureLoader;

public class Main  {

    public static Camera cam;
    static ArrayList<Float> corDispX = new  ArrayList<>();
    static ArrayList<Float> corDispZ = new  ArrayList<>();
    public static void main(String[] args) {
        initDisplay();
        initGL();
        gameLoop();
        cleanUp();
        
    }

    public static void initGL()  {
        
        cam=new Camera(70, (float)Display.getWidth() / (float)Display.getHeight()  ,0.3f ,500);
        /*glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        gluPerspective(30, (float) Display.EtWidth() / (float) Display.getHeight(), 1f,
        200);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();*/
        
        glClearColor(0, 0, 0, 1);

        glEnable(GL_DEPTH_TEST);
        //glEnable(GL_CULL_FACE);
       glCullFace(GL_BACK);
       //glEnable(GL_LIGHTING);
       glEnable(GL_LIGHT0);      
        glLightf(GL_LIGHT0, GL_AMBIENT, 0.5f);
        glLightf(GL_LIGHT0, GL_DIFFUSE, 0.6f);
        glLightf(GL_LIGHT0, GL_POSITION, 0.7f);      
       glShadeModel(GL_SMOOTH);      
       glEnable(GL_COLOR_MATERIAL);
       glEnable(GL_TEXTURE_2D);
         
    }

    public static void gameLoop() {       
              
        Texture tPiso=loadTexture("pisoverde");
        Texture tPiso2=loadTexture("pisomadera");
        Texture tPiso3=loadTexture("pisoajedrez2");
        while (!Display.isCloseRequested()) {
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            glShadeModel(GL_SMOOTH);
            glLoadIdentity();
            //gluLookAt(-5, 4, 200, 0, 0, 5, 0, 1, 0);
            cam.useView();
            tPiso.bind();
            glBegin(GL_QUADS);
            {
                glTexCoord2f(0,0);glVertex3f(-1.59f,-0.5f,-3f);
                glTexCoord2f(20,0);glVertex3f(-1.59f,-0.5f,5.5f);
                glTexCoord2f(20,20);glVertex3f(5.1f,-0.5f,5.5f);
                glTexCoord2f(0,20);glVertex3f(5.1f,-0.5f,-4f);
            }
            
            glEnd(); 
            tPiso2.bind();
            glBegin(GL_QUADS);
            {
                glTexCoord2f(0,0);glVertex3f(-0.03f,-0.49f,-1f);
                glTexCoord2f(20,0);glVertex3f(-0.03f,-0.49f,3.0f);
                glTexCoord2f(20,20);glVertex3f(4.0f,-0.49f,3.0f);
                glTexCoord2f(0,20);glVertex3f(4.0f,-0.49f,-1f);
            }
                  glEnd();                    
            tPiso3.bind();
            glBegin(GL_QUADS);
            {
                glTexCoord2f(0,0);glVertex3f(-0.03f,-0.47f,-1f);
                glTexCoord2f(20,0);glVertex3f(-0.03f,-0.47f,0.25f);
                glTexCoord2f(20,20);glVertex3f(0.8f,-0.47f,0.25f);
                glTexCoord2f(0,20);glVertex3f(0.8f,-0.47f,-1f);
            }
                  glEnd();
            float pInX=0.5f,pInZ=0.1f;
            glTranslatef(0,0,0);
            dibujarParedGrande(1);            
            corDispZ.add(pInZ);
            corDispZ.add(pInZ-1);
            corDispX.add(pInX);
            corDispX.add(pInX-1);
            //System.out.println(pInZ+" - "+(pInZ-1)+" - "+pInX+" - "+(pInX-1));
            glTranslatef(0,0,0.8f);
            dibujarPuerta();           
            glTranslatef(0,0,1.35f);           
            dibujarparedunaVentana(1);
                        
            
            glRotatef(90.0f,1.0f,90.0f,0.0f);            
            glTranslatef(-0.85f,0,1.0f);            
            dibujarParedGrandeVentanaPequeña(1);
            
            
            glRotatef(270.0f,0.0f,90.0f,0.0f); 
            glTranslatef(0.3f,0,0.02f);            
            dibujarParedGrandeVentanaPequeñaMosaico(1);
            
            glTranslatef(0,0,-1.35f);
            dibujarPuerta2(); 
            
            glRotatef(90.0f,0.0f,90.0f,0.0f); 
            glTranslatef(0.5f,0,-0.3f);            
            dibujarParedGrandeamarilloPiedra(1);
            
            
           glRotatef(180.0f,0.0f,90.0f,0.0f); 
            glTranslatef(-0.9f,0,0.70f);            
            dibujarParedGrandeMosaicoPiedra(1);
            
            glRotatef(90.0f,0.0f,90.0f,0.0f); 
            glTranslatef(0.5f,0,-0.35f);
            dibujarPuerta3();
            
            
            glRotatef(270.0f,0.0f,90.0f,0.0f); 
            glTranslatef(-0.93f,0,0f);           
            dibujarparedunaVentanaPequeña(1);
            
            
            glTranslatef(0,0,-0.85f);           
            dibujarparedunaVentanaPiedra(1);
            
            glTranslatef(0,0,-2f);           
            dibujarparedunaVentanaPequeñaPiedra(1);
            
            
            glRotatef(270.0f,0.0f,90.0f,0.0f);
            glTranslatef(-0.35f,0,-0.3f);
            dibujarParedGrandeLarga(1); 
            
            
             glTranslatef(0,0,-2.7f);           
            dibujarparedunaVentanaAzul(1);
            
            
            glRotatef(270.0f,0.0f,90.0f,0.0f);
            glTranslatef(-1,0,-.48f);           
            dibujarParedGrandeMorado(1);
            
            
            
            glRotatef(180.0f,0.0f,90.0f,0.0f);
            glTranslatef(-1.8f,0,0.5f);           
            dibujarParedGrandeMoradoLadrillo(1);
            
            
            
            glRotatef(-90.0f,0.0f,90.0f,0.0f); 
            glTranslatef(0.51f,0,-0.85f);            
            dibujarParedGrandeVentanaPequeñaMosaicoAzul(1);
            
            
            //glRotatef(-90.0f,0.0f,90.0f,0.0f);
             glTranslatef(0,0,0.5f);
            dibujarPuerta2Azul();
            
            
            
            glRotatef(270.0f,0.0f,90.0f,0.0f); 
            glTranslatef(-1.45f,0,-0.86f);           
            dibujarparedunaVentanaPequeñaMosaico(1);
            
            
            glRotatef(180.0f,0.0f,90.0f,0.0f); 
            glTranslatef(-0.95f,0,-0.0f);
            dibujarPuerta4();
            
            
            
                         
            glRotatef(180.0f,0.0f,90.0f,0.0f); 
            glTranslatef(-0.5f,0,0.18f);
            dibujarPuertaBaño();  
            
            
            glEnable(GL_BLEND);    
            glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
            
            glRotatef(90.0f,0.0f,90.0f,0.0f); 
            glTranslatef(-2.15f,0.47f,0.85f);
            dibujarVentanaGrande(1);
            
            
            
            
            glRotatef(180.0f,0.0f,0.0f,0.0f); 
            glTranslatef(-3.95f,0.57f,0.72f);
            dibujarVentanaGrande(1);
            
            
            
             glRotatef(90.0f,0f,270.0f,0.0f); 
            glTranslatef(3.42f,-0.f,2.25f);
            dibujarVentanaGrande(1);
            
            
            glTranslatef(0f,0.0f,1.7f);
            dibujarVentanaMediana(1);
            
            
            glTranslatef(0f,0.14f,-2.83f);
            dibujarVentanaMediana(1);
            
            
            
            glTranslatef(-4f,-0.38f,1.695f);
            dibujarVentanaChica(1);
            
            
            //dibujarParedGrandeVentanaPequeñaMosaico(1);
            controles();
            Display.update();
        }
    }
public static void dibujarParedGrande(float size){
    Texture tParedroja=loadTexture("paredmosaico2");
    Texture tParedblanca=loadTexture("paredblanca");
    tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.3f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.3f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.3f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.3f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,size/2,.3f);
            glTexCoord2d(0,1);glVertex3f(size/40,size/2,.3f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);
        tParedroja.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-size/2,.3f);
            glTexCoord2d(0,1); glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,size/2, .3f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,.3f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .3f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
public static void dibujarVentanaGrande(float size){
    Texture tVentanaazul=loadTexture("ventanaazul");
    tVentanaazul.bind();                                  
        glBegin(GL_QUADS);
            glEnable(GL_BLEND);    
            glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.08f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.08f);
                glTexCoord2d(1,1);glVertex3f(size/40,-0.075f,0.08f);
                glTexCoord2d(1,0);glVertex3f(-size/40,-0.075f, 0.08f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.075f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.075f, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.075f,0.08f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.075f,0.08f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.075f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.075f, -1);
            
        //CARA izquierda
        //glColor3f(0,size/2,0);
        
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-size/2,0.08f);
            glTexCoord2d(0,1); glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.07f,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,-0.07f, 0.08f);
            
         //CARA derecha
        
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.08f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,-0.07f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.07f,0.08f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
public static void dibujarVentanaMediana(float size){
    Texture tVentanaazul=loadTexture("ventanaazul");
    tVentanaazul.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-0.54f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-0.54f);
                glTexCoord2d(1,1);glVertex3f(size/40,-0.075f,-0.54f);
                glTexCoord2d(1,0);glVertex3f(-size/40,-0.075f, -0.54f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.075f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.075f, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.075f,-0.54f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.075f,-0.54f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.075f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.075f, -1);
            
        //CARA izquierda
        //glColor3f(0,size/2,0);
        
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-size/2,-0.54f);
            glTexCoord2d(0,1); glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.07f,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,-0.07f, -0.54f);
            
         //CARA derecha
        
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-0.54f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,-0.07f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.07f,-0.54f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
public static void dibujarVentanaChica(float size){
    Texture tVentanaazul=loadTexture("ventanaazul");
    tVentanaazul.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-0.2f,-0.84f);
                glTexCoord2d(0,1);glVertex3f(size/40,-0.2f,-0.84f);
                glTexCoord2d(1,1);glVertex3f(size/40,-0.075f,-0.84f);
                glTexCoord2d(1,0);glVertex3f(-size/40,-0.075f, -0.84f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.2f,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.2f,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.075f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.075f, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.075f,-0.84f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.075f,-0.84f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.075f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.075f, -1);
            
        //CARA izquierda
        //glColor3f(0,size/2,0);
        
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-0.2f,-0.84f);
            glTexCoord2d(0,1); glVertex3f(size/40,-0.2f,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.07f,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,-0.07f, -0.84f);
            
         //CARA derecha
        
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.2f,-0.84f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-0.2f,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,-0.07f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.07f,-0.84f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
public static void dibujarParedGrandeMorado(float size){
    Texture tParedroja=loadTexture("paredmorado");
    Texture tParedblanca=loadTexture("paredblanca");
    tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.5f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.5f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.5f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.5f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,size/2,.5f);
            glTexCoord2d(0,1);glVertex3f(size/40,size/2,.5f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);
        tParedroja.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-size/2,.5f);
            glTexCoord2d(0,1); glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,size/2, .5f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,.5f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .5f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
public static void dibujarParedGrandeMoradoLadrillo(float size){
    Texture tParedmorado=loadTexture("paredmorado");
    Texture tParedblanca=loadTexture("paredblanca");
    Texture tParedladrillo=loadTexture("paredladrillo");
    tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.5f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.5f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.5f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.5f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,size/2,.5f);
            glTexCoord2d(0,1);glVertex3f(size/40,size/2,.5f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);
        tParedmorado.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-size/2,.5f);
            glTexCoord2d(0,1); glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,size/2, .5f);
             glEnd();
         //CARA derecha
         tParedladrillo.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,.5f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .5f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
public static void dibujarParedGrandeLarga(float size){
    Texture tParedroja=loadTexture("paredroja");
    Texture tParedblanca=loadTexture("paredblanca");
    tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.3f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.3f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.3f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.3f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-2);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-2);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-2);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -2);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,size/2,0.3f);
            glTexCoord2d(0,1);glVertex3f(size/40,size/2,0.3f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-3);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -3);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);
        tParedroja.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-size/2,.3f);
            glTexCoord2d(0,1); glVertex3f(size/40,-size/2,-1.75f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1.75f);
            glTexCoord2d(1,0);glVertex3f(size/40,size/2, .3f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,.3f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-size/2,-1.75f);
            glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-1.75f);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .3f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
public static void dibujarParedGrandeVentanaPequeña(float size){
    Texture tParedamarillo=loadTexture("paredamarillo");
    Texture tParedblanca=loadTexture("paredblanca"); 
    tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.3f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.3f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.3f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.3f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,size/2,.3f);
            glTexCoord2d(0,1);glVertex3f(size/40,size/2,.3f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);
        tParedamarillo.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-size/2,.3f);
            glTexCoord2d(0,1); glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,size/2, .3f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,.3f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .3f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
public static void dibujarParedGrandeamarilloPiedra(float size){
    Texture tParedpiedra=loadTexture("paredpiedra");
    Texture tParedamarillo=loadTexture("paredamarillo"); 
    Texture tParedblanca=loadTexture("paredblanca"); 
    tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.3f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.3f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.3f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.3f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,size/2,.3f);
            glTexCoord2d(0,1);glVertex3f(size/40,size/2,.3f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);
        tParedpiedra.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-size/2,.3f);
            glTexCoord2d(0,1); glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,size/2, .3f);
             glEnd();
         //CARA derecha
         tParedamarillo.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,.3f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .3f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
public static void dibujarParedGrandeMosaicoPiedra(float size){
    Texture tParedpiedra=loadTexture("paredpiedra");
    Texture tParedmosaico=loadTexture("paredmosaico2");
    Texture tParedblanca=loadTexture("paredblanca"); 
    tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.3f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.3f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.3f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.3f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-0.5f);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-0.5f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-0.5f);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -0.5f);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,size/2,0.3f);
            glTexCoord2d(0,1);glVertex3f(size/40,size/2,.3f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-0.5f);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -0.5f);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);
        tParedpiedra.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-size/2,.3f);
            glTexCoord2d(0,1); glVertex3f(size/40,-size/2,-0.5f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-0.5f);
            glTexCoord2d(1,0);glVertex3f(size/40,size/2, .3f);
             glEnd();
         //CARA derecha
         tParedmosaico.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,.3f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-size/2,-0.5f);
            glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-0.5f);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .3f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
public static void dibujarParedGrandeVentanaPequeñaMosaico(float size){
    Texture tParedmosaico=loadTexture("paredmosaico");
    Texture tParedbech=loadTexture("paredbech"); 
    Texture tParedblanca=loadTexture("paredblanca"); 
    tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.0f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.0f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.0f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.0f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,size/2,.0f);
            glTexCoord2d(0,1);glVertex3f(size/40,size/2,.0f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);
        tParedmosaico.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-size/2,.0f);
            glTexCoord2d(0,1); glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,size/2, .0f);
             glEnd();
         //CARA derecha
         tParedbech.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,.0f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .0f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
public static void dibujarParedGrandeVentanaPequeñaMosaicoAzul(float size){
    Texture tParedmosaico=loadTexture("paredmosaico");
    Texture tParedazul=loadTexture("paredazul"); 
    Texture tParedblanca=loadTexture("paredblanca"); 
    tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.0f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.0f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.0f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.0f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,size/2,.0f);
            glTexCoord2d(0,1);glVertex3f(size/40,size/2,.0f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);
        tParedmosaico.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-size/2,.0f);
            glTexCoord2d(0,1); glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,size/2, .0f);
             glEnd();
         //CARA derecha
         tParedazul.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,.0f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .0f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
public static void dibujarparedunaVentana(float size){
    Texture tParedbech=loadTexture("paredbech");
    Texture tParedblanca=loadTexture("paredblanca"); 
     tParedblanca.bind();
    glBegin(GL_QUADS);
    //cara frontal
    //glColor3f(size/2,size/2,size/2);
    glNormal3f(0,0,1);
    glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.85f);
    glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.85f);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.85f);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.85f);
    
    //CARA POSTERIOR
    glNormal3f(0,0,-1);
    glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
    glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
    
    //CARA superior
    glNormal3f(0,1,0);
    //glColor3f(size/2,size/2,0);
    
    glTexCoord2d(0,0);glVertex3f(-size/40,size/2,.85f);
    glTexCoord2d(0,1);glVertex3f(size/40,size/2,.85f);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
    glEnd();
    //CARA izquierda
    //glColor3f(0,size/2,0);
    tParedbech.bind();
    glBegin(GL_QUADS);
    glNormal3f(-1,0,0);
    glTexCoord2d(0,0);glVertex3f(size/40,0.4f,.85f);
    glTexCoord2d(0,1); glVertex3f(size/40,0.4f,-1);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
    glTexCoord2d(1,0);glVertex3f(size/40,size/2, .85f);
    glEnd();
    //CARA derecha
    tParedblanca.bind();
    glBegin(GL_QUADS);
    //glColor3f(size/2,size/2,size/2);
    glNormal3f(1,0,0);
    glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,0.85f);
    glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,-1);
    glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-1);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .85f);
    
    //CARA inferior
    /* // glColor3f(size/2,0,size/2);
    glNormal3f(0,-1,0);
    glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
    glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
    glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
    glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
    
    glEnd();
        
        //lado de abajo
        
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.85f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.85f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.85f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.85f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,.85f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.01f,.85f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.01f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.01f, -1);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);       
        tParedbech.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-0.01f,.85f);
            glTexCoord2d(0,1); glVertex3f(size/40,-0.01f,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2, .85f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,0.85f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-0.01f,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2, .85f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
        //ladoderecho de ventana
        
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.340f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.340f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.340f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2,0.340f);
                
                 glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-0.7f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-0.7f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,-0.7f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2,-0.7f);  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,-0.7f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.01f,-0.7f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.01f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.01f, -1);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);       
        tParedbech.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,0.4f,-0.7f);
            glTexCoord2d(0,1); glVertex3f(size/40,0.4f,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2,-0.7f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,-0.7f);
            glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2,-0.7f);
        
            glEnd();
            ///culomna is¿zquierade la ventana--------------------------------------------------------------------------
            
           tParedbech.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,0.4f,0.34f);
            glTexCoord2d(0,1); glVertex3f(size/40,0.4f,0.85f);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,0.85f);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2,0.34f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,0.34f);
            glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,0.85f);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,0.85f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2,0.34f);
        
            glEnd();
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        
        
        
    }
public static void dibujarparedunaVentanaPiedra(float size){
    Texture tParedpiedra=loadTexture("paredpiedra");
    Texture tParedblanca=loadTexture("paredblanca"); 
     tParedblanca.bind();
    glBegin(GL_QUADS);
    //cara frontal
    //glColor3f(size/2,size/2,size/2);
    glNormal3f(0,0,1);
    glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.85f);
    glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.85f);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.85f);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.85f);
    
    //CARA POSTERIOR
    glNormal3f(0,0,-1);
    glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
    glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
    
    //CARA superior
    glNormal3f(0,1,0);
    //glColor3f(size/2,size/2,0);
    
    glTexCoord2d(0,0);glVertex3f(-size/40,size/2,.85f);
    glTexCoord2d(0,1);glVertex3f(size/40,size/2,.85f);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
    glEnd();
    //CARA izquierda
    //glColor3f(0,size/2,0);
    tParedpiedra.bind();
    glBegin(GL_QUADS);
    glNormal3f(-1,0,0);
    glTexCoord2d(0,0);glVertex3f(size/40,0.4f,.85f);
    glTexCoord2d(0,1); glVertex3f(size/40,0.4f,-1);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
    glTexCoord2d(1,0);glVertex3f(size/40,size/2, .85f);
    glEnd();
    //CARA derecha
    tParedblanca.bind();
    glBegin(GL_QUADS);
    //glColor3f(size/2,size/2,size/2);
    glNormal3f(1,0,0);
    glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,0.85f);
    glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,-1);
    glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-1);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .85f);
    
    //CARA inferior
    /* // glColor3f(size/2,0,size/2);
    glNormal3f(0,-1,0);
    glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
    glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
    glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
    glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
    
    glEnd();
        
        //lado de abajo
        
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.85f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.85f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.85f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.85f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,.85f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.01f,.85f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.01f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.01f, -1);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);       
        tParedpiedra.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-0.01f,.85f);
            glTexCoord2d(0,1); glVertex3f(size/40,-0.01f,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2, .85f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,0.85f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-0.01f,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2, .85f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
        //ladoderecho de ventana
        
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.340f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.340f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.340f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2,0.340f);
                
                 glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-0.7f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-0.7f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,-0.7f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2,-0.7f);  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,-0.7f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.01f,-0.7f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.01f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.01f, -1);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);       
        tParedpiedra.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,0.4f,-0.7f);
            glTexCoord2d(0,1); glVertex3f(size/40,0.4f,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2,-0.7f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,-0.7f);
            glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2,-0.7f);
        
            glEnd();
            ///culomna is¿zquierade la ventana--------------------------------------------------------------------------
            
           tParedpiedra.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,0.4f,0.34f);
            glTexCoord2d(0,1); glVertex3f(size/40,0.4f,0.85f);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,0.85f);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2,0.34f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,0.34f);
            glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,0.85f);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,0.85f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2,0.34f);
        
            glEnd();
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        
        
        
    }
public static void dibujarparedunaVentanaAzul(float size){
    Texture tParedpiedra=loadTexture("paredazul");
    Texture tParedblanca=loadTexture("paredblanca"); 
     tParedblanca.bind();
    glBegin(GL_QUADS);
    //cara frontal
    //glColor3f(size/2,size/2,size/2);
    glNormal3f(0,0,1);
    glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.85f);
    glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.85f);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.85f);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.85f);
    
    //CARA POSTERIOR
    glNormal3f(0,0,-1);
    glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
    glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
    
    //CARA superior
    glNormal3f(0,1,0);
    //glColor3f(size/2,size/2,0);
    
    glTexCoord2d(0,0);glVertex3f(-size/40,size/2,.85f);
    glTexCoord2d(0,1);glVertex3f(size/40,size/2,.85f);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
    glEnd();
    //CARA izquierda
    //glColor3f(0,size/2,0);
    tParedpiedra.bind();
    glBegin(GL_QUADS);
    glNormal3f(-1,0,0);
    glTexCoord2d(0,0);glVertex3f(size/40,0.4f,0.95f);
    glTexCoord2d(0,1); glVertex3f(size/40,0.4f,-1);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
    glTexCoord2d(1,0);glVertex3f(size/40,size/2, .95f);
    glEnd();
    //CARA derecha
    tParedblanca.bind();
    glBegin(GL_QUADS);
    //glColor3f(size/2,size/2,size/2);
    glNormal3f(1,0,0);
    glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,0.95f);
    glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,-1);
    glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-1);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .95f);
    
    //CARA inferior
    /* // glColor3f(size/2,0,size/2);
    glNormal3f(0,-1,0);
    glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
    glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
    glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
    glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
    
    glEnd();
        
        //lado de abajo
        
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.85f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.85f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.85f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.85f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,.85f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.01f,.85f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.01f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.01f, -1);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);       
        tParedpiedra.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-0.01f,.85f);
            glTexCoord2d(0,1); glVertex3f(size/40,-0.01f,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2, .85f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,0.85f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-0.01f,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2, .85f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
        //ladoderecho de ventana
        
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.340f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.340f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.340f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2,0.340f);
                
                 glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-0.7f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-0.7f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,-0.7f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2,-0.7f);  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,-0.7f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.01f,-0.7f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.01f,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.01f, -1);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);       
        tParedpiedra.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,0.4f,-0.7f);
            glTexCoord2d(0,1); glVertex3f(size/40,0.4f,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2,-0.7f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,-0.7f);
            glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2,-0.7f);
        
            glEnd();
            ///culomna is¿zquierade la ventana--------------------------------------------------------------------------
            
           tParedpiedra.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,0.4f,0.34f);
            glTexCoord2d(0,1); glVertex3f(size/40,0.4f,0.95f);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,0.95f);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2,0.34f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,0.34f);
            glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,0.95f);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,0.95f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2,0.34f);
        
            glEnd();
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        
        
        
    }
public static void dibujarparedunaVentanaPequeña(float size){
    Texture tParedmosaico=loadTexture("paredmosaico2");
    Texture tParedblanca=loadTexture("paredblanca"); 
     tParedblanca.bind();
    glBegin(GL_QUADS);
    //cara frontal
    //glColor3f(size/2,size/2,size/2);
    glNormal3f(0,0,1);
    glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.85f);
    glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.85f);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.85f);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.85f);
    
    //CARA POSTERIOR
    glNormal3f(0,0,-1);
    glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0);
    glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,0);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0);
    
    //CARA superior
    glNormal3f(0,1,0);
    //glColor3f(size/2,size/2,0);
    
    glTexCoord2d(0,0);glVertex3f(-size/40,size/2,0.85f);
    glTexCoord2d(0,1);glVertex3f(size/40,size/2,.85f);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,0);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0);
    glEnd();
    //CARA izquierda
    //glColor3f(0,size/2,0);
    tParedmosaico.bind();
    glBegin(GL_QUADS);
    glNormal3f(-1,0,0);
    glTexCoord2d(0,0);glVertex3f(size/40,0.2f,0.85f);
    glTexCoord2d(0,1); glVertex3f(size/40,0.2f,0);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,0);
    glTexCoord2d(1,0);glVertex3f(size/40,size/2, .85f);
    glEnd();
    //CARA derecha
    tParedblanca.bind();
    glBegin(GL_QUADS);
    //glColor3f(size/2,size/2,size/2);
    glNormal3f(1,0,0);
    glTexCoord2d(0,0);glVertex3f(-size/40,0.2f,0.85f);
    glTexCoord2d(0,1);glVertex3f(-size/40,0.2f,0);
    glTexCoord2d(1,1);glVertex3f(-size/40,size/2,0);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .85f);
    
    //CARA inferior
    /* // glColor3f(size/2,0,size/2);
    glNormal3f(0,-1,0);
    glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
    glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
    glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
    glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
    
    glEnd();
        
        //lado de abajo
        
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.85f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.85f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.85f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.85f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0f);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,0f);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0f);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.14f,.65f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.14f,.65f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.14f,0f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.14f,0f);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);       
        tParedmosaico.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-0.14f,.85f);
            glTexCoord2d(0,1); glVertex3f(size/40,-0.14f,0f);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,0f);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2, .85f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.14f,0.85f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-0.14f,0);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,0);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2, .85f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
        //ladoderecho de ventana
        
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.640f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.640f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.640f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2,0.640f);
                
                 glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2,0f);  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.2f);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.2f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.2f);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.2f);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,0f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.01f,0f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.01f,0.2f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.01f, 0.2f);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);       
        tParedmosaico.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,0.4f,0f);
            glTexCoord2d(0,1); glVertex3f(size/40,0.4f,0.2f);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,0.2f);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2,0f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,0);
            glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,0.2f);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,0.2f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2,0);
        
            glEnd();
            ///culomna is¿zquierade la ventana--------------------------------------------------------------------------
            
           tParedmosaico.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,0.4f,0.64f);
            glTexCoord2d(0,1); glVertex3f(size/40,0.4f,0.85f);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,0.85f);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2,0.64f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,0.64f);
            glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,0.85f);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,0.85f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2,0.64f);
        
            glEnd();
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        
        
        
    }
public static void dibujarparedunaVentanaPequeñaMosaico(float size){
    Texture tParedmosaico=loadTexture("paredmosaico");
    Texture tParedblanca=loadTexture("paredblanca"); 
     tParedblanca.bind();
    glBegin(GL_QUADS);
    //cara frontal
    //glColor3f(size/2,size/2,size/2);
    glNormal3f(0,0,1);
    glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.85f);
    glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.85f);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.85f);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.85f);
    
    //CARA POSTERIOR
    glNormal3f(0,0,-1);
    glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0);
    glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,0);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0);
    
    //CARA superior
    glNormal3f(0,1,0);
    //glColor3f(size/2,size/2,0);
    
    glTexCoord2d(0,0);glVertex3f(-size/40,0.5f,0.85f);
    glTexCoord2d(0,1);glVertex3f(size/40,0.5f,.85f);
    glTexCoord2d(1,1);glVertex3f(size/40,0.5f,-0.38f);
    glTexCoord2d(1,0);glVertex3f(-size/40,0.5f, -0.38f);
    glEnd();
    //CARA izquierda
    //glColor3f(0,size/2,0);
    tParedmosaico.bind();
    glBegin(GL_QUADS);
    glNormal3f(-1,0,0);
    glTexCoord2d(0,0);glVertex3f(size/40,0.35f,0.85f);
    glTexCoord2d(0,1); glVertex3f(size/40,0.35f,-0.38f);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,-0.38f);
    glTexCoord2d(1,0);glVertex3f(size/40,size/2, .85f);
    glEnd();
    //CARA derecha
    tParedblanca.bind();
    glBegin(GL_QUADS);
    //glColor3f(size/2,size/2,size/2);
    glNormal3f(1,0,0);
    glTexCoord2d(0,0);glVertex3f(-size/40,0.35f,0.85f);
    glTexCoord2d(0,1);glVertex3f(-size/40,0.35f,-0.38f);
    glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-0.38f);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, .85f);
    
    //CARA inferior
    /* // glColor3f(size/2,0,size/2);
    glNormal3f(0,-1,0);
    glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
    glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
    glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
    glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
    
    glEnd();
        
        //lado de abajo
        
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.85f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.85f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.85f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.85f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0f);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,0f);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0f);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,0.2f,.65f);
            glTexCoord2d(0,1);glVertex3f(size/40,0.2f,.65f);
            glTexCoord2d(1,1);glVertex3f(size/40,0.2f,0f);
            glTexCoord2d(1,0);glVertex3f(-size/40,0.2f,0f);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);       
        tParedmosaico.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,0.2f,.85f);
            glTexCoord2d(0,1); glVertex3f(size/40,0.2f,0f);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,0f);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2,0.85f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,0.2f,0.85f);
            glTexCoord2d(0,1);glVertex3f(-size/40,0.2f,0);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,0);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2, .85f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
        //ladoderecho de ventana
        
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.640f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.640f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.640f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2,0.640f);
                
                 glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-0.4f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-0.4f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,-0.4f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2,-0.4f);  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.2f);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.2f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.2f);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.2f);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,-0.4f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.01f,-0.4f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.01f,0.2f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.01f, 0.2f);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);       
        tParedmosaico.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,0.4f,-0.4f);
            glTexCoord2d(0,1); glVertex3f(size/40,0.4f,0.2f);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,0.2f);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2,-0.4f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,-0.38f);
            glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,0.2f);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,0.2f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2,-0.38f);
        
            glEnd();
            ///culomna is¿zquierade la ventana--------------------------------------------------------------------------
            
           tParedmosaico.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,0.4f,0.35f);
            glTexCoord2d(0,1); glVertex3f(size/40,0.4f,0.85f);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,0.85f);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2,0.35f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,0.35f);
            glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,0.85f);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,0.85f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2,0.35f);
        
            glEnd();
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        
        
        
    }
public static void dibujarparedunaVentanaPequeñaPiedra(float size){
    Texture tParedpiedra=loadTexture("paredpiedra");
    Texture tParedblanca=loadTexture("paredblanca"); 
     tParedblanca.bind();
    glBegin(GL_QUADS);
    //cara frontal
    //glColor3f(size/2,size/2,size/2);
    glNormal3f(0,0,1);
    glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.85f);
    glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.85f);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.85f);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.85f);
    
    //CARA POSTERIOR
    glNormal3f(0,0,-1);
    glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0);
    glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,0);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0);
    
    //CARA superior
    glNormal3f(0,1,0);
    //glColor3f(size/2,size/2,0);
    
    glTexCoord2d(0,0);glVertex3f(-size/40,size/2,1f);
    glTexCoord2d(0,1);glVertex3f(size/40,size/2,1f);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,-0.38f);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -0.38f);
    glEnd();
    //CARA izquierda
    //glColor3f(0,size/2,0);
    tParedpiedra.bind();
    glBegin(GL_QUADS);
    glNormal3f(-1,0,0);
    glTexCoord2d(0,0);glVertex3f(size/40,0.4f,1f);
    glTexCoord2d(0,1); glVertex3f(size/40,0.4f,-0.38f);
    glTexCoord2d(1,1);glVertex3f(size/40,size/2,-0.38f);
    glTexCoord2d(1,0);glVertex3f(size/40,size/2,1f);
    glEnd();
    //CARA derecha
    tParedblanca.bind();
    glBegin(GL_QUADS);
    //glColor3f(size/2,size/2,size/2);
    glNormal3f(1,0,0);
    glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,1f);
    glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,-0.38f);
    glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-0.38f);
    glTexCoord2d(1,0);glVertex3f(-size/40,size/2,1f);
    
    //CARA inferior
    /* // glColor3f(size/2,0,size/2);
    glNormal3f(0,-1,0);
    glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
    glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
    glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
    glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
    
    glEnd();
        
        //lado de abajo
        
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.85f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.85f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.85f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.85f);
                  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0f);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,0f);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0f);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,1.65f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.01f,1.65f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.01f,0f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.01f,0f);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);       
        tParedpiedra.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-0.01f,1.85f);
            glTexCoord2d(0,1); glVertex3f(size/40,-0.01f,0f);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,0f);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2, 1.85f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,1.85f);
            glTexCoord2d(0,1);glVertex3f(-size/40,-0.01f,0);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,0);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2, 1.85f);
        
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
        //ladoderecho de ventana
        
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,1.0f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,1.0f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,1.0f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2,1.0f);
                
                 glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0f);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0f);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,0f);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2,0f);  
        //CARA POSTERIOR                                         
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,0.2f);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,0.2f);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,0.2f);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 0.2f);
           
            //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,-0.01f,0f);
            glTexCoord2d(0,1);glVertex3f(size/40,-0.01f,0f);
            glTexCoord2d(1,1);glVertex3f(size/40,-0.01f,0.2f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-0.01f, 0.2f);
            glEnd();
        //CARA izquierda
        //glColor3f(0,size/2,0);       
        tParedpiedra.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,0.4f,-0.37f);
            glTexCoord2d(0,1); glVertex3f(size/40,0.4f,0.2f);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,0.2f);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2,-0.37f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,-0.37f);
            glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,0.2f);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,0.2f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2,-0.37f);
        
            glEnd();
            ///culomna is¿zquierade la ventana--------------------------------------------------------------------------
            
           tParedpiedra.bind();                                  
        glBegin(GL_QUADS);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,0.4f,0.64f);
            glTexCoord2d(0,1); glVertex3f(size/40,0.4f,1f);
            glTexCoord2d(1,1);glVertex3f(size/40,-size/2,1f);
            glTexCoord2d(1,0);glVertex3f(size/40,-size/2,0.64f);
             glEnd();
         //CARA derecha
         tParedblanca.bind();                                  
        glBegin(GL_QUADS);
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,0.4f,0.64f);
            glTexCoord2d(0,1);glVertex3f(-size/40,0.4f,1f);
            glTexCoord2d(1,1);glVertex3f(-size/40,-size/2,1f);
            glTexCoord2d(1,0);glVertex3f(-size/40,-size/2,0.64f);
        
            glEnd();
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        
        
        
    }
public static void dibujarPuerta(){
    Texture tParedblanca=loadTexture("paredblanca");   
    Texture tParedroja=loadTexture("paredroja");
                               
//-------------------------   
        tParedblanca.bind();
        glBegin(GL_QUADS);
        
        //colunam derecha--------------------------------------
        //cara frontal
        //glColor3f(0.5,0.5,0.5);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.5f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,-0.5f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.5f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,-0.5f);
                    
          //cara atars

             glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.4f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,-0.4f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.4f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,-0.4f);
           
                  
                  
                  //columan aizquierda.------------------------------------------------
                  
        //cara frontal
        //glColor3f(0.5,0.5,0.5);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.35f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,0.35f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,0.35f);
                
                
                
             glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.25f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,0.25f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.25f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,0.25f);
           
             
        //CARA POSTERIOR                                                 
            //CARA superior arriba
        glNormal3f(0,1,0);
        //glColor3f(0.5,0.5,0);
        
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(0,1);glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, 0.35f);
            
            
             //CARA superior abajo
        glNormal3f(0,1,0);
        //glColor3f(0.5,0.5,0);
        
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.4f,-0.5f);
            glTexCoord2d(0,1);glVertex3f(0.025f,0.4f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.4f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.4f, 0.35f);
                                           
                
//-------------------------------------------------------------------------------
        
          ///columna derecha---------------------------------------------------------------------
          //CARA derecha enfrente
         //glColor3f(0.5,0.5,0.5);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.4f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,-0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, -0.4f);
            //columana izquerda-----------
            
          //CARA derecha enfrente
         //glColor3f(0.5,0.5,0.5);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.25f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,-0.5f,0.35f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, 0.25f);
            
            
              //CARA derecha arriba atras
         //glColor3f(0.5,0.5,0.5);
         
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.5f,0.35f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.4f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.4f, 0.35f);
         glEnd();        
        tParedroja.bind();
        glBegin(GL_QUADS);
  
        //lado izquierda endfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,-0.5f,-0.4f);
            glTexCoord2d(0,1); glVertex3f(0.025f,-0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.5f, -0.4f);
         

          //columna izquierda---------------------------------------------------------------------
          
          
            //lado izquierda endfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,-0.5f,0.25f);
            glTexCoord2d(0,1); glVertex3f(0.025f,-0.5f,0.35f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.5f, 0.25f);
         
            
            //---------------------------------------------------------------------------------------------
            
          

            
        //lado izquierda arriba enfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(0,1); glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.4f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.4f, 0.35f);
            
        //CARA inferior
        /* // glColor3f(0.5,0,0.5);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-0.5,0.5);
        glTexCoord2d(0,1);glVertex3f(size/9,-0.5,0.5);
        glTexCoord2d(1,1);glVertex3f(size/9,-0.5,-0.5);
        glTexCoord2d(1,0);glVertex3f(-size/9,-0.5, -0.5); */
        
        glEnd();
        
        
    }
public static void dibujarPuertaBaño(){
    Texture tParedblanca=loadTexture("paredbaño");   
    Texture tParedroja=loadTexture("paredbaño");
                               
//-------------------------   
        tParedblanca.bind();
        glBegin(GL_QUADS);
        
        //colunam derecha--------------------------------------
        //cara frontal
        //glColor3f(0.5,0.5,0.5);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.5f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,-0.5f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.5f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,-0.5f);
                    
          //cara atars

             glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.4f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,-0.4f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.4f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,-0.4f);
           
                  
                  
                  //columan aizquierda.------------------------------------------------
                  
        //cara frontal
        //glColor3f(0.5,0.5,0.5);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.35f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,0.35f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,0.35f);
                
                
                
             glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,0);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,0);
           
             
        //CARA POSTERIOR                                                 
            //CARA superior arriba
        glNormal3f(0,1,0);
        //glColor3f(0.5,0.5,0);
        
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(0,1);glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.68f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, 0.68f);
            
            
             //CARA superior abajo
        glNormal3f(0,1,0);
        //glColor3f(0.5,0.5,0);
        
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.4f,-0.5f);
            glTexCoord2d(0,1);glVertex3f(0.025f,0.4f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.4f,0.68f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.4f, 0.68f);
                                           
                
//-------------------------------------------------------------------------------
        
          ///columna derecha---------------------------------------------------------------------
          //CARA derecha enfrente
         //glColor3f(0.5,0.5,0.5);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.4f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,-0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, -0.4f);
            //columana izquerda-----------
            
          //CARA derecha enfrente
         //glColor3f(0.5,0.5,0.5);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.0f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,-0.5f,0.68f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.5f,0.68f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, 0f);
            
            
              //CARA derecha arriba atras
         //glColor3f(0.5,0.5,0.5);
         
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.5f,0.68f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.4f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.4f, 0.68f);
         glEnd();        
        tParedroja.bind();
        glBegin(GL_QUADS);
  
        //lado izquierda endfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,-0.5f,-0.4f);
            glTexCoord2d(0,1); glVertex3f(0.025f,-0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.5f, -0.4f);
         

          //columna izquierda---------------------------------------------------------------------
          
          
            //lado izquierda endfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,-0.5f,0);
            glTexCoord2d(0,1); glVertex3f(0.025f,-0.5f,0.68f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.68f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.5f, 0);
         
            
            //---------------------------------------------------------------------------------------------
            
          

            
        //lado izquierda arriba enfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,0.5f,0.68f);
            glTexCoord2d(0,1); glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.4f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.4f, 0.68f);
            
        //CARA inferior
        /* // glColor3f(0.5,0,0.5);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-0.5,0.5);
        glTexCoord2d(0,1);glVertex3f(size/9,-0.5,0.5);
        glTexCoord2d(1,1);glVertex3f(size/9,-0.5,-0.5);
        glTexCoord2d(1,0);glVertex3f(-size/9,-0.5, -0.5); */
        
        glEnd();
        
        
    }
public static void dibujarPuerta2(){
    Texture tParedbech=loadTexture("paredbech"); 
    Texture tParedblanca=loadTexture("paredblanca");
    Texture tParedroja=loadTexture("paredroja");
                               
//-------------------------   
        tParedbech.bind();
        glBegin(GL_QUADS);
        
        //colunam derecha--------------------------------------
        //cara frontal
        //glColor3f(0.5,0.5,0.5);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.5f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,-0.5f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.5f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,-0.5f);
                    
          //cara atars

             glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.4f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,-0.4f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.4f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,-0.4f);
           
                  
                  
                  //columan aizquierda.------------------------------------------------
                  
        //cara frontal
        //glColor3f(0.5,0.5,0.5);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.35f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,0.35f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,0.35f);
                
                
                
             glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.25f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,0.25f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.25f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,0.25f);
           
             
        //CARA POSTERIOR                                                 
            //CARA superior arriba
            glEnd();
        glNormal3f(0,1,0);
        //glColor3f(0.5,0.5,0);
        tParedblanca.bind();
        glBegin(GL_QUADS);
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(0,1);glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, 0.35f);
            
         glEnd();
         tParedbech.bind();
        glBegin(GL_QUADS);
             //CARA superior abajo
        glNormal3f(0,1,0);
        //glColor3f(0.5,0.5,0);
        
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.4f,-0.5f);
            glTexCoord2d(0,1);glVertex3f(0.025f,0.4f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.4f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.4f, 0.35f);
                                           
                
//-------------------------------------------------------------------------------
        
          ///columna derecha---------------------------------------------------------------------
          //CARA derecha enfrente
         //glColor3f(0.5,0.5,0.5);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.4f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,-0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, -0.4f);
            //columana izquerda-----------
            
          //CARA derecha enfrente
         //glColor3f(0.5,0.5,0.5);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.25f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,-0.5f,0.35f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, 0.25f);
            
            
              //CARA derecha arriba atras
         //glColor3f(0.5,0.5,0.5);
         
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.5f,0.35f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.4f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.4f, 0.35f);
         glEnd();        
        tParedroja.bind();
        glBegin(GL_QUADS);
  
        //lado izquierda endfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,-0.5f,-0.4f);
            glTexCoord2d(0,1); glVertex3f(0.025f,-0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.5f, -0.4f);
         

          //columna izquierda---------------------------------------------------------------------
          
          
            //lado izquierda endfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,-0.5f,0.25f);
            glTexCoord2d(0,1); glVertex3f(0.025f,-0.5f,0.35f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.5f, 0.25f);
         
            
            //---------------------------------------------------------------------------------------------
            
          

            
        //lado izquierda arriba enfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(0,1); glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.4f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.4f, 0.35f);
            
        //CARA inferior
        /* // glColor3f(0.5,0,0.5);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-0.5,0.5);
        glTexCoord2d(0,1);glVertex3f(size/9,-0.5,0.5);
        glTexCoord2d(1,1);glVertex3f(size/9,-0.5,-0.5);
        glTexCoord2d(1,0);glVertex3f(-size/9,-0.5, -0.5); */
        
        glEnd();
        
        
    }
public static void dibujarPuerta2Azul(){
    Texture tParedazul=loadTexture("paredazul"); 
    Texture tParedblanca=loadTexture("paredblanca");
    Texture tParedroja=loadTexture("paredroja");
                               
//-------------------------   
        tParedazul.bind();
        glBegin(GL_QUADS);
        
        //colunam derecha--------------------------------------
        //cara frontal
        //glColor3f(0.5,0.5,0.5);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.5f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,-0.5f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.5f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,-0.5f);
                    
          //cara atars

             glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.4f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,-0.4f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.4f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,-0.4f);
           
                  
                  
                  //columan aizquierda.------------------------------------------------
                  
        //cara frontal
        //glColor3f(0.5,0.5,0.5);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.35f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,0.35f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,0.35f);
                
                
                
             glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.25f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,0.25f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.25f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,0.25f);
           
             
        //CARA POSTERIOR                                                 
            //CARA superior arriba
            glEnd();
        glNormal3f(0,1,0);
        //glColor3f(0.5,0.5,0);
        tParedblanca.bind();
        glBegin(GL_QUADS);
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(0,1);glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, 0.35f);
            
         glEnd();
         tParedazul.bind();
        glBegin(GL_QUADS);
             //CARA superior abajo
        glNormal3f(0,1,0);
        //glColor3f(0.5,0.5,0);
        
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.4f,-0.5f);
            glTexCoord2d(0,1);glVertex3f(0.025f,0.4f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.4f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.4f, 0.35f);
                                           
                
//-------------------------------------------------------------------------------
        
          ///columna derecha---------------------------------------------------------------------
          //CARA derecha enfrente
         //glColor3f(0.5,0.5,0.5);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.4f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,-0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, -0.4f);
            //columana izquerda-----------
            
          //CARA derecha enfrente
         //glColor3f(0.5,0.5,0.5);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.25f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,-0.5f,0.35f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, 0.25f);
            
            
              //CARA derecha arriba atras
         //glColor3f(0.5,0.5,0.5);
         
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.5f,0.35f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.4f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.4f, 0.35f);
         glEnd();        
        tParedroja.bind();
        glBegin(GL_QUADS);
  
        //lado izquierda endfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,-0.5f,-0.4f);
            glTexCoord2d(0,1); glVertex3f(0.025f,-0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.5f, -0.4f);
         

          //columna izquierda---------------------------------------------------------------------
          
          
            //lado izquierda endfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,-0.5f,0.25f);
            glTexCoord2d(0,1); glVertex3f(0.025f,-0.5f,0.35f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.5f, 0.25f);
         
            
            //---------------------------------------------------------------------------------------------
            
          

            
        //lado izquierda arriba enfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(0,1); glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.4f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.4f, 0.35f);
            
        //CARA inferior
        /* // glColor3f(0.5,0,0.5);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-0.5,0.5);
        glTexCoord2d(0,1);glVertex3f(size/9,-0.5,0.5);
        glTexCoord2d(1,1);glVertex3f(size/9,-0.5,-0.5);
        glTexCoord2d(1,0);glVertex3f(-size/9,-0.5, -0.5); */
        
        glEnd();
        
        
    }
public static void dibujarPuerta3(){
    Texture tParedmosaico=loadTexture("paredmosaico2"); 
    Texture tParedblanca=loadTexture("paredblanca");
    Texture tParedroja=loadTexture("paredroja");
                               
//-------------------------   
        tParedmosaico.bind();
        glBegin(GL_QUADS);
        
        //colunam derecha--------------------------------------
        //cara frontal
        //glColor3f(0.5,0.5,0.5);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.91f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,-0.91f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.91f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,-0.91f);
                    
          //cara atars

             glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.3f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,-0.3f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.3f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,-0.3f);
           
                  
                  
                  //columan aizquierda.------------------------------------------------
                  
        //cara frontal
        //glColor3f(0.5,0.5,0.5);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.35f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,0.35f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,0.35f);
                
                
                
             glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.25f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,0.25f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.25f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,0.25f);
           
             
        //CARA POSTERIOR                                                 
            //CARA superior arriba
            glEnd();
        glNormal3f(0,1,0);
        //glColor3f(0.5,0.5,0);
        tParedblanca.bind();
        glBegin(GL_QUADS);
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.5f,-0.91f);
            glTexCoord2d(0,1);glVertex3f(0.025f,0.5f,-0.91f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, 0.35f);
            
         glEnd();
         tParedmosaico.bind();
        glBegin(GL_QUADS);
             //CARA superior abajo
        glNormal3f(0,1,0);
        //glColor3f(0.5,0.5,0);
        
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.4f,-0.5f);
            glTexCoord2d(0,1);glVertex3f(0.025f,0.4f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.4f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.4f, 0.35f);
                                           
                
//-------------------------------------------------------------------------------
        
          ///columna derecha---------------------------------------------------------------------
          //CARA derecha enfrente
         //glColor3f(0.5,0.5,0.5);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.3f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,-0.5f,-0.91f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.5f,-0.91f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, -0.3f);
            //columana izquerda-----------
            
          //CARA derecha enfrente
         //glColor3f(0.5,0.5,0.5);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.25f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,-0.5f,0.35f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, 0.25f);
            
            
              //CARA derecha arriba atras
         //glColor3f(0.5,0.5,0.5);
         
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.5f,0.35f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.4f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.4f, 0.35f);
         glEnd();        
        tParedroja.bind();
        glBegin(GL_QUADS);
  
        //lado izquierda endfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,-0.5f,-0.3f);
            glTexCoord2d(0,1); glVertex3f(0.025f,-0.5f,-0.91f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.91f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.5f, -0.3f);
         

          //columna izquierda---------------------------------------------------------------------
          
          
            //lado izquierda endfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,-0.5f,0.25f);
            glTexCoord2d(0,1); glVertex3f(0.025f,-0.5f,0.35f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.5f, 0.25f);
         
            
            //---------------------------------------------------------------------------------------------
            
          

            
        //lado izquierda arriba enfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(0,1); glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.4f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.4f, 0.35f);
            
        //CARA inferior
        /* // glColor3f(0.5,0,0.5);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-0.5,0.5);
        glTexCoord2d(0,1);glVertex3f(size/9,-0.5,0.5);
        glTexCoord2d(1,1);glVertex3f(size/9,-0.5,-0.5);
        glTexCoord2d(1,0);glVertex3f(-size/9,-0.5, -0.5); */
        
        glEnd();
        
        
    }
public static void dibujarPuerta4(){
    Texture tParedpiedra=loadTexture("paredpiedra"); 
    Texture tParedblanca=loadTexture("paredblanca");
    Texture tParedmosaico=loadTexture("paredmosaico");
                               
//-------------------------   
        tParedpiedra.bind();
        glBegin(GL_QUADS);
        
        //colunam derecha--------------------------------------
        //cara frontal
        //glColor3f(0.5,0.5,0.5);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.84f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,-0.84f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.84f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,-0.84f);
                    
          //cara atars

             glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.3f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,-0.3f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.3f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,-0.3f);
           
                  
                  
                  //columan aizquierda.------------------------------------------------
                  
        //cara frontal
        //glColor3f(0.5,0.5,0.5);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.35f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,0.35f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,0.35f);
                
                
                
             glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.25f);
                glTexCoord2d(0,1);glVertex3f(0.025f,-0.5f,0.25f);
                glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.25f);
                glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f,0.25f);
           
             
        //CARA POSTERIOR                                                 
            //CARA superior arriba
            glEnd();
        glNormal3f(0,1,0);
        //glColor3f(0.5,0.5,0);
        tParedblanca.bind();
        glBegin(GL_QUADS);
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.5f,-0.84f);
            glTexCoord2d(0,1);glVertex3f(0.025f,0.5f,-0.84f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, 0.35f);
            
         glEnd();
         tParedpiedra.bind();
        glBegin(GL_QUADS);
             //CARA superior abajo
        glNormal3f(0,1,0);
        //glColor3f(0.5,0.5,0);
        
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.4f,-0.5f);
            glTexCoord2d(0,1);glVertex3f(0.025f,0.4f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.4f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.4f, 0.35f);
                                           
                
//-------------------------------------------------------------------------------
        
          ///columna derecha---------------------------------------------------------------------
          //CARA derecha enfrente
         //glColor3f(0.5,0.5,0.5);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,-0.3f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,-0.5f,-0.84f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.5f,-0.84f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, -0.3f);
            //columana izquerda-----------
            
          //CARA derecha enfrente
         //glColor3f(0.5,0.5,0.5);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,-0.5f,0.25f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,-0.5f,0.35f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.5f, 0.25f);
            
            
              //CARA derecha arriba atras
         //glColor3f(0.5,0.5,0.5);
         
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-0.025f,0.5f,0.35f);
            glTexCoord2d(0,1);glVertex3f(-0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(-0.025f,0.4f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(-0.025f,0.4f, 0.35f);
         glEnd();        
        tParedmosaico.bind();
        glBegin(GL_QUADS);
  
        //lado izquierda endfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,-0.5f,-0.3f);
            glTexCoord2d(0,1); glVertex3f(0.025f,-0.5f,-0.84f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,-0.84f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.5f, -0.3f);
         

          //columna izquierda---------------------------------------------------------------------
          
          
            //lado izquierda endfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,-0.5f,0.25f);
            glTexCoord2d(0,1); glVertex3f(0.025f,-0.5f,0.35f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.5f, 0.25f);
         
            
            //---------------------------------------------------------------------------------------------
            
          

            
        //lado izquierda arriba enfrente
        //glColor3f(0,0.5,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(0.025f,0.5f,0.35f);
            glTexCoord2d(0,1); glVertex3f(0.025f,0.5f,-0.5f);
            glTexCoord2d(1,1);glVertex3f(0.025f,0.4f,-0.5f);
            glTexCoord2d(1,0);glVertex3f(0.025f,0.4f, 0.35f);
            
        //CARA inferior
        /* // glColor3f(0.5,0,0.5);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-0.5,0.5);
        glTexCoord2d(0,1);glVertex3f(size/9,-0.5,0.5);
        glTexCoord2d(1,1);glVertex3f(size/9,-0.5,-0.5);
        glTexCoord2d(1,0);glVertex3f(-size/9,-0.5, -0.5); */
        
        glEnd();
        
        
    }
    public static void controles() {
        
        
        boolean forward=Keyboard.isKeyDown(Keyboard.KEY_W);
        boolean backward=Keyboard.isKeyDown(Keyboard.KEY_S);
        boolean left=Keyboard.isKeyDown(Keyboard.KEY_A);
        boolean right=Keyboard.isKeyDown(Keyboard.KEY_D);
        
        boolean up=Keyboard.isKeyDown(Keyboard.KEY_E);
        boolean donw=Keyboard.isKeyDown(Keyboard.KEY_C);
        
        float mx= Mouse.getDX();
        float my= Mouse.getDY();
        
        mx*=0.10f;
        my*=0.10f;
        
        if(Mouse.isButtonDown(0)){
            cam.rotateY(mx);
            cam.rotateX(-my);
        }
        
        if(forward){
            /* //System.out.println(cam.getX()+"  -   "+cam.getY()+"  -   "+cam.getZ());
            for(int g=0;g<corDispZ.size();g+=2){
            System.out.println((cam.getZ()+Math.sin(Math.toRadians(cam.getRy()+90)))+" - "+corDispZ.get(g)+" - "+corDispZ.get(g+1));
            if((cam.getZ())<corDispZ.get(g) && (cam.getZ()>corDispZ.get(g+1))){
            cam.moveZ(0.009f);
            }
            }*/
            cam.moveZ(0.5f);  
            
                        
        }
        if(backward){
            /* for(int g=0;g<corDispZ.size();g+=2){
            //System.out.println((cam.getZ()+Math.sin(Math.toRadians(cam.getRy()+90)))+""+corDispZ.get(g+1));
            if((cam.getZ()-Math.sin(Math.toRadians(cam.getRy()+90)))<corDispZ.get(g) && (cam.getZ()-Math.sin(Math.toRadians(cam.getRy()+90)))>corDispZ.get(g+1)){
            cam.moveZ(0.009f);
            }
            }*/
            cam.moveZ(-0.5f);
        }
        if(left){
            cam.moveX(0.5f);
        }
        if(right){
            cam.moveX(-0.5f);
        }
          if(up){
              if(cam.getY()>=0)return;
        cam.moveY(0.5f);
        }
        if(donw){
        cam.moveY(-0.5f);
        }
        if (Keyboard.isKeyDown(Keyboard.KEY_ESCAPE)) {
            cleanUp();
        }
        
    }
    public static void cleanUp() {
        Display.destroy();
        System.exit(0);
    }
    public static void initDisplay() {
        try {
            Display.setDisplayMode(new DisplayMode(800, 600));
            Display.setTitle("Laberinto en openGL. Lwjgl: " + Sys.getVersion());
            Display.create();
        } catch (LWJGLException ex) {
            ex.printStackTrace();
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            System.exit(0);
        }
    }
    public static Texture loadTexture(String key) {
        try {
            return TextureLoader.getTexture("png", new FileInputStream(
                    new File("res/" + key + ".png")));

        } catch (IOException ex) {
            Logger.getLogger(Main.class
                    .getName()).log(
                            Level.SEVERE, null, ex);
        }
        return null;
    }
    public static FloatBuffer asFloatBuffer(float[] arreglo) {
        FloatBuffer fb = BufferUtils.createFloatBuffer(arreglo.length);
        fb.put(arreglo);
        fb.flip();
        return fb;
    }
    public static IntBuffer asIntBuffer(int[] arreglo) {
        IntBuffer ib = BufferUtils.createIntBuffer(arreglo.length);
        ib.put(arreglo);
        ib.flip();
        return ib;
    }
}
