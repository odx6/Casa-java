/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package futuroingeniero;

import static org.lwjgl.opengl.GL11.*;

/**
 *
 * @author tauro
 */
public class Cubo {
    
    public void dibujarParedGrande(float size){
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,1);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,1);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,1);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 1);
        //CARA POSTERIOR
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
        //CARA izquierda
        //glColor3f(0,size/2,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-size/2,1);
            glTexCoord2d(0,1); glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,size/2, 1);
         //CARA derecha
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,1);
            glTexCoord2d(0,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 1);
        //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,size/2,1);
            glTexCoord2d(0,1);glVertex3f(size/40,size/2,1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
     public void drawCube(float size){
        glBegin(GL_QUADS);
        //cara frontal
        //glColor3f(size/2,size/2,size/2);        
           glNormal3f(0,0,1);            
                glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,1);
                glTexCoord2d(0,1);glVertex3f(size/40,-size/2,1);
                glTexCoord2d(1,1);glVertex3f(size/40,size/2,1);
                glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 1);
        //CARA POSTERIOR
        glNormal3f(0,0,-1);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(0,1);glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
        //CARA izquierda
        //glColor3f(0,size/2,0);
        glNormal3f(-1,0,0);
            glTexCoord2d(0,0);glVertex3f(size/40,-size/2,1);
            glTexCoord2d(0,1); glVertex3f(size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(size/40,size/2, 1);
         //CARA derecha
         //glColor3f(size/2,size/2,size/2);
         glNormal3f(1,0,0);
            glTexCoord2d(0,0);glVertex3f(-size/40,-size/2,1);
            glTexCoord2d(0,1);glVertex3f(-size/40,-size/2,-1);
            glTexCoord2d(1,1);glVertex3f(-size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, 1);
        //CARA superior
        glNormal3f(0,1,0);
        //glColor3f(size/2,size/2,0);
        
            glTexCoord2d(0,0);glVertex3f(-size/40,size/2,1);
            glTexCoord2d(0,1);glVertex3f(size/40,size/2,1);
            glTexCoord2d(1,1);glVertex3f(size/40,size/2,-1);
            glTexCoord2d(1,0);glVertex3f(-size/40,size/2, -1);
        //CARA inferior
        /* // glColor3f(size/2,0,size/2);
        glNormal3f(0,-1,0);
        glTexCoord2d(0,0);glVertex3f(-size/9,-size/2,size/2);
        glTexCoord2d(0,1);glVertex3f(size/9,-size/2,size/2);
        glTexCoord2d(1,1);glVertex3f(size/9,-size/2,-size/2);
        glTexCoord2d(1,0);glVertex3f(-size/9,-size/2, -size/2); */
        
        glEnd();
        
        
    }
}
